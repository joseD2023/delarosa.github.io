/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete_controlador;

/**
 *
 * @author Admin
 */
import javax.swing.JOptionPane;
public class Controlador_login {
     private final String usuarioAdmin = "josedelarosa";  // Usuario fijo del administrador
    private final String contraseñaAdmin = "1234"; // Contraseña fija del administrador

    public boolean verificarCredenciales(String usuario, String contraseña) {
        if (usuario.equals(usuarioAdmin) && contraseña.equals(contraseñaAdmin)) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos", "Error de acceso", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
