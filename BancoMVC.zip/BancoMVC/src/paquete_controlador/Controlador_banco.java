    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */
    package paquete_controlador;

    /**
     *
     * @author Admin
     */
    import javax.swing.JOptionPane;
    import paquete_modelo.Banco;
    import paquete_modelo.Usuario;
    import paquete_modelo.Cuenta;
    import java.util.List;
    import java.util.Random;
    public class Controlador_banco {
        private Banco banco;

        //Controlador banco 
        //Contructor Banco 
        public Controlador_banco(Banco banco){
            this.banco = banco;

        }
        public void registrar_usuario(String cui, String nombre, String apellido){
            banco.registrarUsuario(cui, nombre, apellido);  // ✔ Se usa correctamente el método existente

        }//termina registrar u suario 

        public void agregar_cuenta_usuario(String cui){
             Usuario usuario = banco.buscarUsuarioPorCui(cui);
            if (usuario != null) {
                Random random = new Random();
                String numeroCuenta = "ACC" + (100000 + random.nextInt(900000)); // Generar número de cuenta
                Cuenta nuevaCuenta = new Cuenta(numeroCuenta, 0.0); // Se crea con saldo inicial 0
                usuario.agregarCuenta(nuevaCuenta);
                JOptionPane.showMessageDialog(null, "Cuenta agregada exitosamente: " + numeroCuenta);
            } else {
                JOptionPane.showMessageDialog(null, "¡Error! Usuario no encontrado.");
            }

        }




       public void depositar(String cui, String numeroCuenta, double cantidad) {
        Usuario usuario = banco.buscarUsuarioPorCui(cui);
        if (usuario != null) {
            for (Cuenta cuenta : usuario.getCuentas()) {
                if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                    cuenta.depositar(cantidad);
                    JOptionPane.showMessageDialog(null, "Depósito exitoso. Nuevo saldo: " + cuenta.getSaldo());
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "No se encontró la cuenta.");
        } else {
            JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
        }
    }

    public void retirar(String cui, String numeroCuenta, double cantidad) {
        Usuario usuario = banco.buscarUsuarioPorCui(cui);
        if (usuario != null) {
            for (Cuenta cuenta : usuario.getCuentas()) {
                if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                    if (cuenta.retirar(cantidad)) {
                        JOptionPane.showMessageDialog(null, "Retiro exitoso. Nuevo saldo: " + cuenta.getSaldo());
                    } else {
                        JOptionPane.showMessageDialog(null, "Saldo insuficiente.");
                    }
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "No se encontró la cuenta.");
        } else {
            JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
        }
    }

    public Cuenta obtenerCuentaPorCUI(String cui) {
        for (Usuario usuario : banco.getListaUsuarios()) {
            System.out.println("Verificando usuario: " + usuario.getCui()); // Debug
            if (usuario.getCui().trim().equals(cui.trim())) { // Asegurar coincidencia exacta
                if (!usuario.getCuentas().isEmpty()) { 
                    return usuario.getCuentas().get(0); // Devuelve la primera cuenta
                } else {
                    System.out.println("El usuario no tiene cuentas.");
                    return null;
                }
            }
        }
        System.out.println("No se encontró usuario con CUI: " + cui);
        return null;
    }
    public boolean depositar2(String cui, double monto) {
        Cuenta cuenta = obtenerCuentaPorCUI(cui);
        if (cuenta == null) {
            JOptionPane.showMessageDialog(null, "No se encontró la cuenta para el CUI: " + cui);
            return false;
        }

        if (monto <= 0) {
            JOptionPane.showMessageDialog(null, "El monto debe ser mayor a 0.");
            return false;
        }

        cuenta.depositar(monto);
        JOptionPane.showMessageDialog(null, "Depósito exitoso. Nuevo saldo: " + cuenta.getSaldo());
        return true;
    }






    }
