package paquete_modelo;

import java.util.Date;
import javax.swing.JOptionPane;

public class Transaccion {
    private static int contador_id = 1; // Para generar identificadores únicos de transacción
    private String id;
    private Date fechaHora;
    private String tipo;
    private double monto;
    private double saldoDisponible;
    
    // Agregar estas variables para el monto debitado y acreditado
    private double montoDebitado;
    private double montoAcreditado;

    public Transaccion(String tipo, double monto) {
        this.id = "T" + contador_id++;  // Genera un identificador único
        this.fechaHora = new Date(); // Fecha y hora de la transacción
        this.tipo = tipo;
        this.monto = monto;
        this.saldoDisponible = 0; // Inicializamos el saldo disponible en 0
        
        // Dependiendo del tipo de transacción, asignamos los valores a montoDebitado o montoAcreditado
        if (tipo.equals("Retiro")) {
            this.montoDebitado = monto;
            this.montoAcreditado = 0; // Para retiro, no hay monto acreditado
        } else if (tipo.equals("Deposito")) {
            this.montoAcreditado = monto;
            this.montoDebitado = 0; // Para depósito, no hay monto debitado
        }
    }

    // Método setter para el saldo disponible
    public void setSaldoDisponible(double saldoDisponible) {
        this.saldoDisponible = saldoDisponible;
    }

    // Métodos getters
    public String getId() {
        return id;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public String getTipo() {
        return tipo;
    }

    public double getMonto() {
        return monto;
    }

    public double getSaldoDisponible() {
        return saldoDisponible;
    }

    public double getMontoDebitado() {
        return montoDebitado;
    }

    public double getMontoAcreditado() {
        return montoAcreditado;
    }

    @Override
    public String toString() {
        return "Transacción ID: " + id + ", Fecha: " + fechaHora + ", Tipo: " + tipo + ", Monto: " + monto + ", Saldo Disponible: " + saldoDisponible;
    }
    
    // Métodos existentes que no eliminamos
    public static void realizarDeposito(Usuario usuario, String numeroCuenta, double cantidad) {
        for (Cuenta cuenta : usuario.getCuentas()) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                cuenta.depositar(cantidad);
                JOptionPane.showMessageDialog(null, "Depósito realizado con éxito. Nuevo saldo: " + cuenta.getSaldo());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
    }

    public static void realizarRetiro(Usuario usuario, String numeroCuenta, double cantidad) {
        for (Cuenta cuenta : usuario.getCuentas()) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                if (cuenta.retirar(cantidad)) {
                    JOptionPane.showMessageDialog(null, "Retiro exitoso. Nuevo saldo: " + cuenta.getSaldo());
                } else {
                    JOptionPane.showMessageDialog(null, "Saldo insuficiente.");
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
    }
}
