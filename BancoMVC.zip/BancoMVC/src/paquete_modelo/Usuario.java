/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete_modelo;

/**
 *
 * @author Admin
 */
import java.util.ArrayList;
import java.util.List;
public class Usuario {
    private String cui;
    private String nombre;
    private String apellido;
    private List<Cuenta> cuentas; 
    
    public Usuario(String cui, String nombre, String apellido) {
        this.cui = cui;
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuentas = new ArrayList<>();
    }

    public String getCui() {
        return cui;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }
    
    public List<Cuenta> getCuentas() {
        return cuentas;
    }
    
    public void agregarCuenta(Cuenta cuenta) {
        cuentas.add(cuenta);
    }
    
   @Override
public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Usuario: ").append(nombre).append(" ").append(apellido).append(" | CUI: ").append(cui).append("\nCuentas: ");
    for (Cuenta cuenta : cuentas) {
        sb.append(cuenta.getNumeroCuenta()).append(" ");
    }
    return sb.toString();
}

    
    public List<Transaccion> obtenerHistorialTransacciones() {
    List<Transaccion> historial = new ArrayList<>();
    for (Cuenta cuenta : cuentas) {
        historial.addAll(cuenta.getHistorialTransacciones());
    }
    return historial;
}

    
    
}
