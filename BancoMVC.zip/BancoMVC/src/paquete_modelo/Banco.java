package paquete_modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

public class Banco {
    private List<Usuario> listaUsuarios;  // Lista para almacenar los usuarios
    private static Banco instancia; // Variable para guardar la única instancia

    // Constructor para inicializar la lista de usuarios
    public Banco() {
        this.listaUsuarios = new ArrayList<>();
    }

    // Método para obtener la instancia del banco (Singleton)
    public static Banco getInstance() {
        if (instancia == null) {
            instancia = new Banco();  // Si no existe, se crea la instancia
        }
        return instancia;  // Retorna la única instancia
    }

    // Método para registrar un usuario en el banco
    public void registrarUsuario(String cui, String nombre, String apellido) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getCui().equals(cui)) {
                JOptionPane.showMessageDialog(null, "¡Error! El CUI ya está registrado.", 
                                              "CUI Duplicado", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        Usuario nuevoUsuario = new Usuario(cui, nombre, apellido);
        listaUsuarios.add(nuevoUsuario);
        JOptionPane.showMessageDialog(null, "Usuario registrado con éxito: " + nombre);
    }

    // Método para agregar una cuenta a un usuario
    public void agregarCuentaUsuario(String cui) {
        Usuario usuario = buscarUsuarioPorCui(cui);  // Buscar el usuario por CUI
        if (usuario != null) {
            Random random = new Random();
            String numeroCuenta = "ACC" + (100000 + random.nextInt(900000)); // Generar número de cuenta
            Cuenta nuevaCuenta = new Cuenta(numeroCuenta, 0.0); // Se crea la cuenta con saldo inicial 0
            usuario.agregarCuenta(nuevaCuenta);  // Agregar la cuenta al usuario
            JOptionPane.showMessageDialog(null, "Cuenta agregada exitosamente: " + numeroCuenta);
        } else {
            JOptionPane.showMessageDialog(null, "¡Error! Usuario no encontrado.");
        }
    }

    // Método para buscar un usuario por CUI
    public Usuario buscarUsuarioPorCui(String cui) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getCui().equals(cui)) {
                return usuario;
            }
        }
        return null;
    }

    // Método para obtener el historial de transacciones de un usuario y su cuenta
    public List<Transaccion> obtenerHistorialTransacciones(String cui, String numeroCuenta) {
        for (Usuario usuario : listaUsuarios) {  // Aquí ya usamos listaUsuarios
            if (usuario.getCui().equals(cui)) {  // Verificamos si el CUI coincide
                for (Cuenta cuenta : usuario.getCuentas()) {  // Iteramos sobre las cuentas del usuario
                    if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {  // Comparamos el número de cuenta
                        return cuenta.getHistorialTransacciones(); // Obtenemos el historial de transacciones de la cuenta
                    }
                }
            }
        }
        return null; // Si no se encuentra la cuenta o usuario
    }

    // Método para realizar un depósito
    public static void realizarDeposito(Usuario usuario, String numeroCuenta, double cantidad) {
        for (Cuenta cuenta : usuario.getCuentas()) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                cuenta.depositar(cantidad);
                Transaccion transaccion = new Transaccion("Deposito", cantidad);
                cuenta.agregarTransaccion(transaccion);  // Añadir la transacción
                JOptionPane.showMessageDialog(null, "Depósito realizado con éxito. Nuevo saldo: " + cuenta.getSaldo());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
    }

    // Método para realizar un retiro
    public static void realizarRetiro(Usuario usuario, String numeroCuenta, double cantidad) {
        for (Cuenta cuenta : usuario.getCuentas()) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                if (cuenta.retirar(cantidad)) {
                    Transaccion transaccion = new Transaccion("Retiro", cantidad);
                    cuenta.agregarTransaccion(transaccion);  // Añadir la transacción
                    JOptionPane.showMessageDialog(null, "Retiro exitoso. Nuevo saldo: " + cuenta.getSaldo());
                } else {
                    JOptionPane.showMessageDialog(null, "Saldo insuficiente.");
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Cuenta no encontrada.");
    }

    // Método para obtener la lista de usuarios del banco
    public List<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }
    
    public Usuario buscarUsuarioPorNumeroCuenta(String numeroCuenta) {
    for (Usuario usuario : listaUsuarios) {
        for (Cuenta cuenta : usuario.getCuentas()) {
            if (cuenta.getNumeroCuenta().equals(numeroCuenta)) {
                return usuario;
            }
        }
    }
    return null; // Si no se encuentra el usuario con esa cuenta
}

}
