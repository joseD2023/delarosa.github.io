/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete_modelo;

/**
 *
 * @author Admin
 */
import java.util.ArrayList;
import java.util.List;
import paquete_modelo.Transaccion;
import javax.swing.JOptionPane;
public class Cuenta {
     private String numeroCuenta;
     private double saldo;
     private List<Transaccion> historialTransacciones;

    public Cuenta(String numeroCuenta, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
        this.historialTransacciones = new ArrayList<>(); // INICIALIZACIÓN AQUÍ
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo ;
    }

   public void depositar(double cantidad) {
        if (cantidad > 0) {
        if (historialTransacciones.size() < 25) {
            saldo += cantidad;
            Transaccion transaccion = new Transaccion("DEPÓSITO", cantidad);
            transaccion.setSaldoDisponible(saldo);
            historialTransacciones.add(transaccion);
        } else {
            JOptionPane.showMessageDialog(null, "No se pueden realizar más de 25 transacciones.");
        }
    }
    }

    public boolean retirar(double cantidad) {
        if (cantidad > 0 && cantidad <= saldo) {
        if (historialTransacciones.size() < 25) {
            saldo -= cantidad;
            Transaccion transaccion = new Transaccion("RETIRO", cantidad);
            transaccion.setSaldoDisponible(saldo);
            historialTransacciones.add(transaccion);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "No se pueden realizar más de 25 transacciones.");
            return false;
        }
    }
    return false;
    }

    public List<Transaccion> getHistorialTransacciones() {
        return historialTransacciones;
    }
    public void agregarTransaccion(Transaccion transaccion) {
    historialTransacciones.add(transaccion);
}
    
    //Obtener cuenta por cui 
    
}
    

