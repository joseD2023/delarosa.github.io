/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete_main;

/**
 *
 * @author Admin
 */
import paquete_vista.Login_vista;
public class Main {
    public static void main(String[] args) {
        // Crear una instancia de la ventana de login y hacerla visible
        Login_vista login = new Login_vista();  // Suponiendo que tu ventana de login se llama "Login"
        login.setVisible(true);
    }
    
}
